
<?php
namespace CreditSystem\Database\Repositories;

use CreditSystem\Database\Repositories\BaseRepository;

if (!defined('ABSPATH')) {
    exit;
}

class TransactionRepository extends BaseRepository
{
    protected string $table;

    public function __construct()
    {
        parent::__construct();
        $this->table = $this->db->prefix . 'credit_transactions';
    }

    /**
     * create new transaction
     */
    public function create(array $data): int|false
    {
        $defaults = [
            'credit_account_id' => null,
            'type'              => '', // charge | payment | penalty | refund
            'amount'            => 0,
            'description'       => '',
            'reference_id'      => null,
            'created_at'        => current_time('mysql'),
        ];

        $data = wp_parse_args($data, $defaults);

        $result = $this->db->insert(
            $this->table,
            [
                'credit_account_id' => (int) $data['credit_account_id'],
                'type'              => sanitize_text_field($data['type']),
                'amount'            => (float) $data['amount'],
                'description'       => sanitize_text_field($data['description']),
                'reference_id'      => $data['reference_id'],
                'created_at'        => $data['created_at'],
            ],
            [
                '%d',
                '%s',
                '%f',
                '%s',
                '%s',
                '%s',
            ]
        );

        if ($result === false) {
            return false;
        }

        return (int) $this->db->insert_id;
    }

    /**
     * get transaction by id
     */
    public function find(int $id): ?object
    {
        $sql = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE id = %d LIMIT 1",
            $id
        );

        $row = $this->db->get_row($sql);

        return $row ?: null;
    }

    /**
     * trasaction list of a credits accounts
     */
    public function getByCreditAccount(int $creditAccountId, int $limit = 50, int $offset = 0): array
    {
        $sql = $this->db->prepare(
            "SELECT * FROM {$this->table}
             WHERE credit_account_id = %d
             ORDER BY created_at DESC
             LIMIT %d OFFSET %d",
            $creditAccountId,
            $limit,
            $offset
        );

        return $this->db->get_results($sql) ?: [];
    }

    /**
     * sum transaction by type
     */
    public function sumByType(int $creditAccountId, string $type): float
    {
        $sql = $this->db->prepare(
            "SELECT SUM(amount)
             FROM {$this->table}
             WHERE credit_account_id = %d AND type = %s",
            $creditAccountId,
            $type
        );

        return (float) $this->db->get_var($sql);
    }

    /**
     * delete transaction
     */
    public function delete(int $id): bool
    {
        return (bool) $this->db->delete(
            $this->table,
            ['id' => $id],
            ['%d']
        );
    }
    /**
     * get last transactins
     */
    public function getLastTransaction(int $creditAccountId): ?object
    {
        $sql = $this->db->prepare(
            "SELECT * FROM {$this->table}
             WHERE credit_account_id = %d
             ORDER BY id DESC
             LIMIT 1",
            $creditAccountId
        );

        $row = $this->db->get_row($sql);

        return $row ?: null;
    }
}
