<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once DIR . '/BaseRepository.php';

class InstallmentRepository extends BaseRepository
{
    protected $table = 'installments';

    /**
     * create new installment
     */
    public function create(array $data): int
    {
        $this->wpdb->insert(
            $this->table(),
            [
                'user_id'            => $data['user_id'],
                'credit_account_id'  => $data['credit_account_id'],
                'transaction_id'     => $data['transaction_id'],
                'due_date'           => $data['due_date'],
                'base_amount'        => $data['base_amount'],
                'penalty_amount'     => 0,
                'total_amount'       => $data['base_amount'],
                'status'             => 'unpaid',
                'created_at'         => current_time('mysql'),
                'updated_at'         => current_time('mysql'),
            ],
            ['%d', '%d', '%d', '%s', '%f', '%f', '%f', '%s', '%s', '%s']
        );

        return (int) $this->wpdb->insert_id;
    }

    /**
     * get installment by user id 
     */
    public function getByUser(int $user_id): array
    {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->table()}
                 WHERE user_id = %d
                 ORDER BY due_date ASC",
                $user_id
            )
        );
    }

    /**
     * get due installments by unpaid or overdue
     */
    public function getDueInstallments(): array
    {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->table()}
                 WHERE status IN ('unpaid', 'overdue')
                   AND due_date < %s",
                current_time('mysql')
            )
        );
    }

    /**
     * apply daily penalty
     */
    public function applyDailyPenalty(int $installment_id): bool
    {
        $rate = defined('CS_PENALTY_RATE_DAILY') ? CS_PENALTY_RATE_DAILY : 0;

        if ($rate <= 0) {
            return false;
        }

        $query = "
            UPDATE {$this->table()}
            SET
                penalty_amount = penalty_amount + (base_amount * %f),
                total_amount   = base_amount + penalty_amount + (base_amount * %f),
                status         = 'overdue',
                updated_at     = %s
            WHERE id = %d
              AND status != 'paid'
        ";

        $result = $this->wpdb->query(
            $this->wpdb->prepare(
                $query,
                $rate,
                $rate,
                current_time('mysql'),
                $installment_id
            )
        );

        return $result === 1;
    }

    /**
     * پرداخت قسط
     */
    public function markAsPaid(int $installment_id): bool
    {
        $result = $this->wpdb->query(
            $this->wpdb->prepare(
                "UPDATE {$this->table()}
                 SET status = 'paid',
                     paid_at = %s,
                     updated_at = %s
                 WHERE id = %d
                   AND status != 'paid'",
                current_time('mysql'),
                current_time('mysql'),
                $installment_id
            )
        );

        return $result === 1;
    }
    /**
     * دریافت قسط قابل پرداخت (برای دکمه پرداخت)
     */
    public function getPayableById(int $installment_id)
    {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->table()}
                 WHERE id = %d
                   AND status IN ('unpaid', 'overdue')
                   AND due_date <= %s
                 LIMIT 1",
                $installment_id,
                current_time('mysql')
            )
        );
    }
}